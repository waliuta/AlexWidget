
var config = {
    map: {
        '*': {
            'prepareDataCondition': 'Dev101_UniversalWidget/js/prepareDataCondition',

        }
    },
    deps: [
        'Magento_Catalog/catalog/product'
    ],

};
